<!DOCTYPE html>
<html>
<head>

			<title>Error al ingresar</title>
</head>

	<body>
			<center>
			<h1><?php echo $_GET['mensaje']; ?></h1>
			<a href="login.php">Vuelva a ingresar</a>



	</body>
</html>
