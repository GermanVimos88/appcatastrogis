<?php

	class Log
	{
		public function __construct($nombre, $path)
		{	
			date_default_timezone_set('America/Guayaquil'); 
			$this->path     = ($path) ? $path : "/";
			$this->nombre 	= ($nombre) ? $nombre : "log";
			$this->fecha    = date("Y-m-d H:i:s");
			$this->ip       = ($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 0;
		}
		public function insert($text, $dated, $clear, $backup)
		{
			if ($dated) {
				$fecha   = "_" . str_replace(" ", "_", $this->fecha);
				$append = null;
			}
			else {
				$fecha   = "";
				$append = ($clear) ? null : FILE_APPEND;
				if ($backup) {
					$result = (copy($this->path . $this->nombre . ".log", $this->path . $this->nombre . "_" . str_replace(" ", "_", $this->fecha) . "-backup.log")) ? 1 : 0;
					$append = ($result) ? $result : FILE_APPEND;
				}
			};
			$log    = $this->fecha . " [ip] " . $this->ip . " [usuario: acción] " . $text . PHP_EOL;
			$result = (file_put_contents($this->path . $this->nombre .  $fecha . ".log", $log, $append)) ? 1 : 0;

			return $result;
		}
	}


?>

