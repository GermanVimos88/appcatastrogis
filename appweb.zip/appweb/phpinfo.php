<?php

//dl("php_mapscript.so");
phpinfo();
?>