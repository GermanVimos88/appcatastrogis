<?php
	
    session_start();

    if (isset($_GET['id'])){
		$id=intval($_GET['id']); //talvez funcione con inv_codigo_investigacion
	} else {
		header("location:VistaInvestigaciones.php");
	}

	//Falta controlar el inicio de sesión


 if($_POST['Salir']){ // cuando presiona el botón salir
    header('Location: index.php');
    //unset($_SESSION['id_usuario']); //destruye la sesión
      }



?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Actualizar datos de Investigaciones</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="css/custom.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



<script>
function populate(s1,s2){
  var s1 = document.getElementById(s1);
  var s2 = document.getElementById(s2);
  s2.innerHTML = "";
  if(s1.value == "Pichincha"){
    var optionArray = ["quito|Quito","rumiñahui|Rumiñahui","cayambe|Cayambe","mejía|Mejía","pedro moncayo|Pedro Moncayo","pedro vicente maldondao|Pedro Vicente Maldonado","san miguel de los bancos|San Miguel de los Bancos","puerto quito|Puero Quito"];
  } else if(s1.value == "Azuay"){
    var optionArray = ["cuenca|Cuenca","chordeleg|Chordeleg","sevilla de oro|Sevilla de Oro","paute|Paute","guachapala|Guachapala","el pan|El Pan","gualaceo|Gualaceo","sígsig|Sígsig","santa isabel|Santa Isabel","pucará|Pucará","camilo ponce enríquez|Camilo Ponce Enríquez","san fernando|San Fernando","girón|Girón","nabón|Nabón","oña|Oña"];
  } else if(s1.value == "Imbabura"){
    var optionArray = ["ibarra|Ibarra","san miguel de urcuquí|San Miguel de Urcuquí","cotacachi|Cotacachi","antonio ante|Antonio Ante","otavalo|Otavalo","pimampiro|Pimampiro"];
  } else if(s1.value == "Guayas"){
    var optionArray = ["milagro|Milagro","guayaquil|Guayaquil","durán|Durán","el empalme|El Empalme","balzar|Balzar","colimes|Colimes","palestina|Palestina","santa lucía|Santa Lucía","pedro carbo|Pedro Carbo","isidro ayora|Isidro Ayora","lomas de sargentillo|Lomas de Sargentillo","nobol|Nobol","daule|Daule","salitre|Salitre","samborondón|Samborondón","yaguachi|Yaguachi","alfredo baquerizo|Alfredo Baquerizo","simón bolívar|Simón Bolívar","naranjito|Naranjito","general antonio elizalde|General Antonio Elizalde","coronel marcelino maridueña|coronel Marcelino Maridueña","el triunfo|El Triunfo","playas|Playas","naranjal|Naranjal","balao|Balao"];
  } else if(s1.value == "Esmeraldas"){
    var optionArray = ["san lorenzo|San Lorenzo","eloy alfaro|Eloy Alfaro","rioverde|Rioverde","esmeraldas|Esmeraldas","muisne|Muisne","atacames|Atacames","quinindé|Quinindé"];
  } else if(s1.value == "Carchi"){
    var optionArray = ["tulcán|Tulcán","mira|Mira","espejo|Espejo","montúfar|Montúfar","san pedro de huaca|San Pedro de Huaca","bolívar|Bolívar"];
  } else if(s1.value == "Sucumbíos"){
    var optionArray = ["sucumbíos|Sucumbíos","gonzalo pizarro|Gonzalo Pizarro","cascales|Cascales","lago agrio|Lago Agrio","putumayo|Putumayo","cuyabeno|Cuyabeno","shushufindi|Shushufindi"];
  } else if(s1.value == "Manabí"){
    var optionArray = ["pedernales|Pedernales","chone|Chone","flavio alfaro|Flavio Alfaro","el carmen|El Carmen","jama|Jama","san vicente|San Vicente","sucre|Sucre","tosagua|Tosagua","rocafuerte|Rocafuerte","junín|Junín","bolívar|Bolívar","pichincha|Pichincha","portoviejo|Portoviejo","jaramijó|Jaramijó","manta|Manta","montecristi|Montecristi","santa ana|Santa Ana","jipijapa|Jipijapa","24 de mayo|24 de Mayo","olmedo|Olmedo","puerto lópez|Puero López","paján|Paján"];
  } else if(s1.value == "Santo Domingo de los Tsáchilas"){
    var optionArray = ["la concordia|La Concordia","santo domingo|Santo Domingo"];
  } else if(s1.value == "Napo"){
    var optionArray = ["el chaco|El Chaco","quijos|Quijos","archidona|Archidona","tena|Tena","carlos julio arosemena tola|Carlos Julio Arosemena Tola"];
  } else if(s1.value == "Orellana"){
    var optionArray = ["loreto|Loreto","orellana|Orellana","la joya de los sachas|La Joya de los Sachas","aguarico|Aguarico"];
  } else if(s1.value == "Pastaza"){
    var optionArray = ["mera|Mera","santa clara|Santa Clara","arajuno|Arajuno","pastaza|Pastaza"];
  } else if(s1.value == "Los Ríos"){
    var optionArray = ["buena fé|Buena Fé","valencia|Valencia","quevedo|Quevedo","quinsaloma|Quinsaloma","palenque|Palenque","mocache|Mocache","ventanas|Ventanas","vinces|Vinces","baba|Baba","puebloviejo|Puebloviejo","urdaneta|Urdaneta","babahoyo|Babahoyo","montalvo|Montalvo"];
  } else if(s1.value == "Cotopaxi"){
    var optionArray = ["sigchos|Sigchos","la maná|La Maná","latacunga|Latacunga","saquisilí|Saquisilí","pujilí|Pujilí","pangua|Pangua","salcedo|Salcedo"];
  } else if(s1.value == "Bolívar"){
    var optionArray = ["guaranda|Guaranda","las naves|Las Naves","echeandía|Echeandía","caluma|Caluma","chimbo|Chimbo","san miguel|San Miguel","chillanes|Chillanes"];
  } else if(s1.value == "Tungurahua"){
    var optionArray = ["ambato|Ambato","píllaro|Pillaro","patate|Patate","baños|Baños","pelileo|Pelileo","cevallos|Cevallos","tisaleo|Tisaleo","mocha|Mocha","quero|Quero"];
  } else if(s1.value == "Chimborazo"){
    var optionArray = ["guano|Guano","penipe|Penipe","riobamba|Riobamba","colta|Colta","chambo|Chambo","pallatanga|Pallatanga","guamote|Guamote","alausí|Alausí","cumandá|Cumandá","chunchi|Chunchi"];
  } else if(s1.value == "Morona Santiago"){
    var optionArray = ["pelora|Palora","pablo sexto|Pablo Sexto","huamboya|Huamboya","morona|Morona","taisha|Taisha","sucúa|Sucúa","santiago|Santiago","logroño|Logroño","tiwintza|Tiwintza","limón indanza|Limón Indanza","san juan bosco|San Juan Bosco","gualaquiza|Gualaquiza"];
  } else if(s1.value == "Santa Elena"){
    var optionArray = ["santa elena|Santa Elena","la libertad|La Libertad","salinas|Salinas"];
  } else if(s1.value == "Cañar"){
    var optionArray = ["la troncal|La Troncal","cañar|Cañar","suscal|Suscal","el tambo|El Tambo","azogues|Azogues","biblián|Biblián","deleg|Deleg"];
  } else if(s1.value == "El Oro"){
    var optionArray = ["el guabo|El Guabo","machala|Machala","pasaje|Pasaje","chilla|Chilla","zaruma|Zaruma","santa rosa|Santa Rosa","atahualpa|Atahualpa","arenillas|Arenillas","huaquillas|Huaquillas","las lajas|Las Lajas","marcabelí|Marcabelí","balsas|Balsas","piñas|Piñas","portovelo|Portovelo"];
  } else if(s1.value == "Loja"){
    var optionArray = ["saraguro|Saraguro","loja|Loja","chaguarpamba|Chaguarpamba","olmedo|Olmedo","catamayo|Catamayo","paltas|Paltas","puyango|Puyango","pindal|Pindal","celica|Celica","zapotillo|Zapotillo","macará|Macará","sozoranga|Sozoranga","calvas|Calvas","gonzanamá|Gonzanamá","quilanga|Quilanga","espíndola|Espíndola"];
  } else if(s1.value == "Zamora Chinchipe"){
    var optionArray = ["yacuambi|Yacuambi","yantzaza|Yantzaza","el pangui|El Pangui","zamora|Zamora","centinela del cóndor|Centinela del Cóndor","paquisha|Paquisha","nangaritza|Nangaritza","palanda|Palanda","chinchipe|Chinchipe"];
  } else if(s1.value == "Galápagos"){
    var optionArray = ["isabela|Isabela","san cristobal|San Cristobal","santa cruz|Santa Cruz"];
  }  else if(s1.value == "Varias"){
    var optionArray = ["varios|Varios"];
  }  



  for(var option in optionArray){
    var pair = optionArray[option].split("|");
    var newOption = document.createElement("option");
    newOption.value = pair[1];   //[0]
    newOption.innerHTML = pair[1];   //[1]
    s2.options.add(newOption);
  }
}
</script>

          <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

              <script type="text/javascript">
        $(document).ready(function () {
            $('#provincia').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#provincia option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                $('#resultadoProvincia').text(selectText);
            });
        
        })

    </script>


     <script type="text/javascript">
        $(document).ready(function () {
            $('#canton').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#canton option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                $('#resultadoCanton').text(selectText);
            });
        
        })

    </script>

     <script type="text/javascript">
        $(document).ready(function () {
            $('#modalidad').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#modalidad option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoModalidad').text(selectText);
            });
        
        })

    </script>


     <script type="text/javascript">
        $(document).ready(function () {
            $('#zona').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#zona option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#anio_inicio').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#anio_inicio option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#mes_inicio').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#mes_inicio option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#dia_inicio').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#dia_inicio option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>


    <script type="text/javascript">
        $(document).ready(function () {
            $('#anio_fin').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#anio_fin option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#mes_fin').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#mes_fin option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

        <script type="text/javascript">
        $(document).ready(function () {
            $('#dia_fin').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#dia_fin option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>


    <script type="text/javascript">
        $(document).ready(function () {
            $('#estado').change(function () {
                // Obtener valor del las opciones selecionadas
               // var selectValue = $("#miselect").val() || [];
                //$("#resultadoValue").text(selectValue);
               

                // Obtener el texto del las opciones selecionadas
                var selectText = $("#estado option:selected").map(function () {
                    return $(this).text();
                }).get().join(',');
                //$('#resultadoZona').text(selectText);
            });
        
        })

    </script>

    



</head>
<body>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Editar <b>Investigación</b></h2></div>
                    <div class="col-sm-4">
                        <a href="VistaInvestigaciones.php" class="btn btn-info add-new"><i class="fa fa-arrow-left"></i> Regresar</a>
                    </div>
                </div>
            </div>
            <?php
				
				include ("database.php");
        include ("actividadUsuario.php");
        //include ("Log.php");
				$investigacion= new Database();
				
				if(isset($_POST) && !empty($_POST)){
					//$nombres = $investigacion->limpiar($_POST['nombres']);
					

					  //intval($_POST['id_inv']);

					  

            


            //$aviso=$investigacion->actualizar_path_ofimatica();    //Funcion para actualizar los nuevos paths de ofimatica con FAS1 al final
      //$avisomul= $investigacion->actualizar_path_multimedia(); //Funcion para actualizar los nuevos paths de multimedia con FAS1 al final

            $cod_inpc=utf8_decode($investigacion->limpiar($_POST["codigoinpc"]));
  					$cod_bibliografia = utf8_decode($investigacion->limpiar($_POST["codigosipce"]));
            $fase= intval($investigacion->limpiar($_POST["fase_inv"])); //fase de la investigación
            $inv_procedente = utf8_decode($investigacion->limpiar($_POST["investigacion_procedente"])); //investigación de la que procede la fase 1
  					$titulo=utf8_decode($investigacion->limpiar($_POST["titulo"]));
  					$modalidad = utf8_decode($investigacion->limpiar($_POST["modalidad"]));
  					$tipo=utf8_decode($investigacion->limpiar($_POST["tipo_investigacion"])); //falta definir en la base de datos
  					$doc_ofi = intval($investigacion->limpiar($_POST["ofimatica"]));
  					$doc_mul = intval($investigacion->limpiar($_POST["multimedia"]));
  					$doc_carto = intval($investigacion->limpiar($_POST["cartografia"]));
  					$provincia = utf8_decode($investigacion->limpiar($_POST["provincia"]));  //utf8_decode para capturar valores del form html con tildes y letra ñ
  					$canton = utf8_decode($investigacion->limpiar($_POST["canton"]));
  					//$parroquia = "Cualquiera";
  					$zona = utf8_decode($investigacion->limpiar($_POST["zona"]));
  					$regional = utf8_decode($investigacion->limpiar($_POST["regional"]));
  					$autorizacion = intval($investigacion->limpiar($_POST["autorizacion"]));
  					//$fecha_inicio = trim($dia_inicio." ".$mes_inicio." ".$anio_inicio);                
  					//$fecha_fin = trim($dia_fin." ".$mes_fin." ".$anio_fin);                        
  					
                    $dia_inicio=utf8_decode($investigacion->limpiar($_POST["dia_inicio"]));            
                    $mes_inicio=utf8_decode($investigacion->limpiar($_POST["mes_inicio"]));
                    $anio_inicio=utf8_decode($investigacion->limpiar($_POST["anio_inicio"]));
                    $dia_fin=utf8_decode($investigacion->limpiar($_POST["dia_fin"]));
                    $mes_fin=utf8_decode($investigacion->limpiar($_POST["mes_fin"]));
                    $anio_fin=utf8_decode($investigacion->limpiar($_POST["anio_fin"]));

                    $estado = utf8_decode($investigacion->limpiar($_POST["estado"]));
  					//$restos = "Si";   //se sugiere eliminar este campo
  					//$calidad = "Muy buena"; //se sugiere eliminar este campo
            //$tipo = utf8_decode($investigacion->limpiar($_POST["tipo_investigacion"]));  //falta agragar este campo a la BD
            $tipo = trim(utf8_decode($_POST["tipoinv1"]." ".$_POST["tipoinv2"]." ".$_POST["tipoinv3"]." ".$_POST["tipoinv4"]." ".$_POST["tipoinv5"]." ".$_POST["tipoinvotros"]));
            $analisis = trim(utf8_decode($_POST["analisis1"]." ".$_POST["analisis2"]." ".$_POST["analisis3"]." ".$_POST["analisisotros"]));

            date_default_timezone_set('America/Guayaquil');  
            $fecha_edicion=date('d/M/Y - g:ia');
            $editado = 'Si';
            $descripcion = utf8_decode($investigacion->limpiar($_POST["descripcion"]));
            $observacion = utf8_decode($investigacion->limpiar($_POST["observaciones"]));



            switch($_SESSION['usuario']){

    case 'jasarrade': $sistematizador = 4;
              break;

    case 'scaspiazu': $sistematizador = 14;
              break;

    case 'wifalcon':  $sistematizador = 1;
              break;
    
    case 'lvuriarte': $sistematizador = 15;
              break;
      
    case 'mynavas':   $sistematizador = 5;
              break;

    case 'baortiz':   $sistematizador = 2;
              break;

    case 'pdfiallos': $sistematizador = 3;
              break;

    case 'fjvaca':    $sistematizador = 6;
              break;

    case 'evargas':   $sistematizador = 9;
              break;

    case 'amendez':   $sistematizador = 10;
              break;

    case 'atrujillo': $sistematizador = 11;  
              break;
   
   case 'durrutia': $sistematizador = 13;  
              break;

    case 'esimbana': $sistematizador = 8;  
              break;

    case 'sosorio': $sistematizador = 7;  
              break;


    case 'usuario': $sistematizador = 20;
              break;

            }                           

					
					

					$res = $investigacion->actualizar_investigacion($cod_inpc,$cod_bibliografia,$fase,$inv_procedente,$titulo,$modalidad,$doc_ofi,$doc_mul,$doc_carto,$provincia,$canton,$regional,$autorizacion,$dia_inicio,$mes_inicio,$anio_inicio,$dia_fin,$mes_fin,$anio_fin,$estado,$restos,$calidad,$editado,$fecha_edicion,$tipo,$analisis,$descripcion,$observacion,$sistematizador,$id);
					if($res){
						$message= "Datos actualizados con éxito";
						$class="alert alert-success";
            //$log = new Log("log", "/home/servipatrimonio/Documents/logs/".$_SESSION['usuario']);
            //echo $log->insert($_SESSION['usuario'].": ".'Esto es un update! en el registro INV-'.$id, false, true, true);
						$log = new actividadUsuario();
            $log->registro_actividad($_SESSION['usuario'],'Actualización de investigación ','INV',$id);


					}else{
						$message="No se pudieron actualizar los datos";
						$class="alert alert-danger";
					}
					
					?>
				<div class="<?php echo $class?>">
				  <?php echo $message;?>
				</div>	
					<?php
				}
				$datos_investigacion=$investigacion->registro_investigacion($id);
			?>
			<div class="row">
				<form method="post">  
				
        
				<div class="col-md-6">
          <br>
					<label>Codigo Investigación: </label> <td><b><?php echo utf8_encode($datos_investigacion->inv_codigo_final);?> </b></td>
					<br>
          <br>
					<label>Codigo INPC:</label>
					<input type="text" name="codigoinpc" id="codigoinpc" class='form-control' maxlength="100" value="<?php echo utf8_encode($datos_investigacion->inv_codigo_inpc);?>">
					<label>Codigo SIPCE:</label>
					<input type="text" name="codigosipce" id="codigosipce" class='form-control' maxlength="100" value="<?php echo utf8_encode($datos_investigacion->inv_codigo_bibliografia);?>">					
				
        <p>
            <tr>
              <br>
              <br>
            <td><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fase:</b></td>
            <td>
              <select id="fase_inv" name="fase_inv">
                <?php
                    echo '<option value="'.utf8_encode($datos_investigacion->inv_fase).'"selected>'.utf8_encode($datos_investigacion->inv_fase).'</option>';                                      
                ?> 
            <option value="">--------------</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            </select> </td>
          </tr>
            </p>


        <p>
            <tr>
              
            <td><b>Investigación precedente:</b></td>
            <td>
              <select id="investigacion_procedente" name="investigacion_procedente">
                
                 <?php
                    echo '<option value="'.utf8_encode($datos_investigacion->inv_investigacion_procedente).'"selected>'.utf8_encode($datos_investigacion->inv_investigacion_procedente).'</option>';                                      
                ?> 
                <option value="">--------------</option>                



                <?php
            $mysqli = new mysqli('localhost', 'root', '', 'mydb1');
          $query = $mysqli -> query ("SELECT inv_codigo_final FROM investigacion ORDER BY inv_codigo_investigacion ASC");
          while ($valores = mysqli_fetch_array($query)) {
            echo '<option value="'.$valores[inv_codigo_final].'">'.$valores[inv_codigo_final].'</option>';
          }
        ?>


            </select> </td>
          </tr>
            </p>





        </div>
				
				<div class="col-md-12">
					<br>
					<label>Título:</label>
					<textarea  name="titulo" id="titulo" class='form-control' maxlength="255" ><?php echo utf8_encode($datos_investigacion->inv_titulo);?></textarea>
				</div>
        <br>
      
        <br>
								
				<div class="col-md-6">
          <hr size="16" />
						<br>
						<tr>
        					<td><b>Modalidad:</b></td>
        					<td>
          					<select id="modalidad" name="modalidad">
                            <?php
                                 echo '<option value="'.utf8_encode($datos_investigacion->inv_modalidad).'"selected>'.utf8_encode($datos_investigacion->inv_modalidad).'</option>';                                      
                            ?> 
                            <option value="">--------------</option>
                            <option value="Investigación">Investigación</option>
                            <option value="Mitigación">Mitigación</option>
                            <option value="No especificada">No especificada</option>
            
          					</select> </td>
     					</tr>

              <p>
            <tr>
              <br>
              <br>
            <td><b>Regional donde se tramita:</b></td>
            <td>
              <select id="regional" name="regional">
                <?php
                    echo '<option value="'.utf8_encode($datos_investigacion->inv_regional_tramite).'"selected>'.utf8_encode($datos_investigacion->inv_regional_tramite).'</option>';                                      
                ?> 
            <option value="">--------------</option>
            <option value="Zonal 1 y 2">Zonal 1 y 2</option>
            <option value="Zonal 3">Zonal 3</option>
            <option value="Zonal 4">Zonal 4</option>
            <option value="Zonal 5">Zonal 5</option>
            <option value="Zonal 6">Zonal 6</option>
            <option value="Zonal 7">Zonal 7</option>
            <option value="No determinada">No determinada</option>
            </select> </td>
          </tr>
            </p>

            <tr>
              <br>
              <br>
                <td><b>Estado del proyecto:</b></td>
                <td>
                  <select name="estado">
                <?php
                 echo '<option value="'.utf8_encode($datos_investigacion->inv_estado).'"selected>'.utf8_encode($datos_investigacion->inv_estado).'</option>';                                      
                ?> 
                <option value="">--------------</option>
                <option value="Solicitada">Solicitada</option>
                <option value="En progreso">En progreso</option>
                <option value="Finalizada">Finalizada</option>
                </select> </td>
                </tr>

				</div>
				

        <section>
				<div class="col-md-6">
          <hr size="16" />
					<br>
					<label>Ofimática:</label>
					<input type="text" name="ofimatica" id="ofimatica"  maxlength="10"  value="<?php echo utf8_encode($datos_investigacion->inv_doc_ofimatica);?>">
				
				
          <br>				
					<br>
					<label>Multimedia:</label>
					<input type="text" name="multimedia" id="multimedia"  maxlength="10"  value="<?php echo utf8_encode($datos_investigacion->inv_doc_imagenes);?>">
				
				
        <br>
				
					<br>
					<label>Cartografía:</label>
					<input type="text" name="cartografia" id="cartografia"  maxlength="10"  value="<?php echo utf8_encode($datos_investigacion->inv_doc_cartografia);?>">
				
          <br>
          <br>
          <label>Número de autorización:</label>
          <input type="text" name="autorizacion" id="autorizacion" class='form-control' maxlength="15" value="<?php echo utf8_encode($datos_investigacion->inv_numero_autorizacion);?>">


        </div>
        </section>

				<br>
				<div class="col-md-6">
					<br>
          <br>
					<tr>
            <hr size="16" />
            			<td><b>Provincia:</b></td>
            			<td>
              			<select id="provincia" name="provincia" onchange="populate(this.id,'canton')">
                        <?php
                            echo '<option value="'.utf8_encode($datos_investigacion->inv_provincia).'"selected>'.utf8_encode($datos_investigacion->inv_provincia).'</option>';                                      
                        ?>    
              
                		<option value="">--------------</option>
            			<option value="Pichincha">Pichincha</option>
            			<option value="Imbabura">Imbabura</option>
            			<option value="Azuay">Azuay</option>
            			<option value="Guayas">Guayas</option>
            			<option value="Cañar">Cañar</option>
            			<option value="Loja">Loja</option>
            			<option value="Bolívar">Bolívar</option>
            			<option value="Manabí">Manabí</option>
            			<option value="Esmeraldas">Esmeraldas</option>
            			<option value="Zamora Chinchipe">Zamora Chinchipe</option>
            			<option value="Pastaza">Pastaza</option>
            			<option value="Napo">Napo</option>
            			<option value="Morona Santiago">Morona Santiago</option>
            			<option value="Orellana">Orellana</option>
            			<option value="Carchi">Carchi</option>
            			<option value="Galápagos">Galápagos</option>
            			<option value="Los Ríos">Los Ríos</option>
            			<option value="El Oro">El Oro</option>
            			<option value="Tungurahua">Tungurahua</option>
            			<option value="Cotopaxi">Cotopaxi</option>
            			<option value="Santa Elena">Santa Elena</option>
            			<option value="Santo Domingo de los Tsáchilas">Santo Domingo de los Tsáchilas</option>
             			<option value="Sucumbíos">Sucumbíos</option> 
             			<option value="Chimborazo">Chimborazo</option>                 
                  <option value="Varias">Varias</option>
           					</select> </td>
           					
         				</tr>
				
				<br>
				

						<tr>
                  <br>
            			<td><b>Cantón:</b> &nbsp;&nbsp;&nbsp;</td>
            			<br>
                  <td>
              			<select id="canton" name="canton">
                            <?php
                            echo '<option value="'.utf8_encode($datos_investigacion->inv_canton).'"selected>'.utf8_encode($datos_investigacion->inv_canton).'</option>';                                      
                        ?> 
                        <option value="">--------------</option>
             			</select> </td>
              			
          				</tr>				
				</div>
					
				
				
				
        <div class="col-md-6">
          <br>
          <br>          
          <hr size="16" />
          
            <label>Fecha de Inicio: </label> 
            <br>
          <tr>
                <td>Año:</td>
                <td>
                  <select name="anio_inicio">
                  <?php
                      echo '<option value="'.$datos_investigacion->inv_anio_inicio_autorizacion.'"selected>'.$datos_investigacion->inv_anio_inicio_autorizacion.'</option>';                                      
                ?>
                <option value="">----------</option>
                <option value="1970">1970</option>
                <option value="1971">1971</option>
                <option value="1972">1972</option>
                <option value="1973">1973</option>
                <option value="1974">1974</option>
                <option value="1975">1975</option>
                <option value="1976">1976</option>
                <option value="1977">1977</option>
                <option value="1978">1978</option>
                <option value="1979">1979</option>
                <option value="1980">1980</option>
                <option value="1981">1981</option>
                <option value="1982">1982</option>
                <option value="1983">1983</option>
                <option value="1984">1984</option>
                <option value="1985">1985</option>
                <option value="1986">1986</option>
                <option value="1987">1987</option>
                <option value="1988">1988</option>
                <option value="1989">1989</option>
                <option value="1990">1990</option>
                <option value="1991">1991</option>
                <option value="1992">1992</option>
                <option value="1993">1993</option>
                <option value="1994">1994</option>
                <option value="1995">1995</option>
                <option value="1996">1996</option>
                <option value="1997">1997</option>
                <option value="1998">1998</option>
                <option value="1999">1999</option>
                <option value="2000">2000</option>
                <option value="2001">2001</option>
                <option value="2002">2002</option>
                <option value="2003">2003</option>
                <option value="2004">2004</option>
                <option value="2005">2005</option>
                <option value="2006">2006</option>
                <option value="2007">2007</option>
                <option value="2008">2008</option>
                <option value="2009">2009</option>
                <option value="2010">2010</option>
                <option value="2011">2011</option>
                <option value="2012">2012</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
                <option value="2016">2016</option>
                <option value="2017">2017</option>
                <option value="2018">2018</option>
                </select> </td>
                </tr>
                <br>
                <tr>
                <td>Mes:</td>
                <td>
                  <select name="mes_inicio">
                <?php                      

                 echo '<option value="'.$datos_investigacion->inv_mes_inicio_autorizacion.'"selected>'.$datos_investigacion->inv_mes_inicio_autorizacion.'</option>';          
                ?>

                <option value="">----------</option>
                <option value="Enero">Enero</option>
                <option value="Febrero">Febrero</option>
                <option value="Marzo">Marzo</option>
                <option value="Abril">Abril</option>
                <option value="Mayo">Mayo</option>
                <option value="Junio">Junio</option>
                <option value="Julio">Julio</option>
                <option value="Agosto">Agosto</option>
                <option value="Septiembre">Septiembre</option>
                <option value="Octubre">Octubre</option>
                <option value="Noviembre">Noviembre</option>
                <option value="Diciembre">Diciembre</option>
                </select> </td>
                </tr>

                <br>
                <tr>
                <td>Día:</td>
                <td>
                  <select name="dia_inicio">
                    <?php                     
                 echo '<option value="'.$datos_investigacion->inv_dia_inicio_autorizacion.'"selected>'.$datos_investigacion->inv_dia_inicio_autorizacion.'</option>';          
                    ?>
                <option value="">----------</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
                </select> </td>
                </tr>

        
          <br>
          <br>
            <label>Fecha de Finalización: </label> 
            <br>
          <tr>
                <td>Año:</td>
                <td>
                  <select name="anio_fin">
                    <?php
                   

            echo '<option value="'.$datos_investigacion->inv_anio_fin_autorizacion.'"selected>'.$datos_investigacion->inv_anio_fin_autorizacion.'</option>';
          
                    ?>
                <option value="">----------</option>
                <option value="1970">1970</option>
                <option value="1971">1971</option>
                <option value="1972">1972</option>
                <option value="1973">1973</option>
                <option value="1974">1974</option>
                <option value="1975">1975</option>
                <option value="1976">1976</option>
                <option value="1977">1977</option>
                <option value="1978">1978</option>
                <option value="1979">1979</option>
                <option value="1980">1980</option>
                <option value="1981">1981</option>
                <option value="1982">1982</option>
                <option value="1983">1983</option>
                <option value="1984">1984</option>
                <option value="1985">1985</option>
                <option value="1986">1986</option>
                <option value="1987">1987</option>
                <option value="1988">1988</option>
                <option value="1989">1989</option>
                <option value="1990">1990</option>
                <option value="1991">1991</option>
                <option value="1992">1992</option>
                <option value="1993">1993</option>
                <option value="1994">1994</option>
                <option value="1995">1995</option>
                <option value="1996">1996</option>
                <option value="1997">1997</option>
                <option value="1998">1998</option>
                <option value="1999">1999</option>
                <option value="2000">2000</option>
                <option value="2001">2001</option>
                <option value="2002">2002</option>
                <option value="2003">2003</option>
                <option value="2004">2004</option>
                <option value="2005">2005</option>
                <option value="2006">2006</option>
                <option value="2007">2007</option>
                <option value="2008">2008</option>
                <option value="2009">2009</option>
                <option value="2010">2010</option>
                <option value="2011">2011</option>
                <option value="2012">2012</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
                <option value="2016">2016</option>
                <option value="2017">2017</option>
                <option value="2018">2018</option>
                </select> </td>
                </tr>
                <br>
                <tr>
                <td>Mes:</td>
                <td>
                  <select name="mes_fin">
                    <?php
                   

            echo '<option value="'.$datos_investigacion->inv_mes_fin_autorizacion.'"selected>'.$datos_investigacion->inv_mes_fin_autorizacion.'</option>';
          
                    ?>
                    <option value="">----------</option>
                <option value="Enero">Enero</option>
                <option value="Febrero">Febrero</option>
                <option value="Marzo">Marzo</option>
                <option value="Abril">Abril</option>
                <option value="Mayo">Mayo</option>
                <option value="Junio">Junio</option>
                <option value="Julio">Julio</option>
                <option value="Agosto">Agosto</option>
                <option value="Septiembre">Septiembre</option>
                <option value="Octubre">Octubre</option>
                <option value="Noviembre">Noviembre</option>
                <option value="Diciembre">Diciembre</option>
                </select> </td>
                </tr>

                <br>
                <tr>
                <td>Día:</td>
                <td>
                  <select name="dia_fin">
                    <?php
                    echo '<option value="'.$datos_investigacion->inv_dia_fin_autorizacion.'"selected>'.$datos_investigacion->inv_dia_fin_autorizacion.'</option>';          
                    ?>

                <option value="">----------</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
                </select> </td>
                </tr>

        </div>

          				
								




          		<div class="col-md-6">
          		<br>	
                <br>    
            <tr>
          <fieldset>  
        <legend>Tipo de investigación</legend> 
        <?php 
            $cadena_tipo = explode(" ", utf8_encode($datos_investigacion->inv_tipo_investigacion));
            ?> 
        <input type="checkbox" name="tipoinv1" value="Diagnóstico"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_tipo[$i]=="Diagnóstico"){?> checked  <?php   } }  ?>   >Diagnóstico<br>  
        <input type="checkbox" name="tipoinv2" value="Prospección"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_tipo[$i]=="Prospección"){?> checked  <?php   } }  ?>   >Prospección<br>  
        <input type="checkbox" name="tipoinv3" value="Excavación"   <?php for ($i=0;$i<5;$i++) {  if ($cadena_tipo[$i]=="Excavación"){?> checked  <?php   } }  ?>  >Excavación<br>
        <input type="checkbox" name="tipoinv4" value="Rescate"    <?php for ($i=0;$i<5;$i++) {  if ($cadena_tipo[$i]=="Rescate"){?> checked  <?php   } }  ?>   >Rescate<br>
        <input type="checkbox" name="tipoinv5" value="Restauración/Conservación"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_tipo[$i]=="Restauración/Conservación"){?> checked  <?php   } }  ?>   >Restauración/Conservación<br>
        <input type="checkbox" name="tipoinv" value="Otros" onclick="document.getElementById('tipootros').disabled = !this.checked">Otros<br>  
        <br>  
        <input name="tipootros" id="tipootros" disabled type="text" maxlength="15" />
        </fieldset>  
          </tr>
           </div>

          <div class="col-md-6">

             <tr>
              <br>
              <br>
        <fieldset>

        <legend>Análisis</legend>  
        <?php 
            $cadena_analisis = explode(" ", utf8_encode($datos_investigacion->inv_analisis));
            ?> 

        <input type="checkbox" name="analisis1" value="C14"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_analisis[$i]=="C14"){?> checked  <?php   } }  ?>  >C14<br>  
        <input type="checkbox" name="analisis2" value="Bioarqueológicos"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_analisis[$i]=="Bioarqueológicos"){?> checked  <?php   } }  ?> >Bioarqueológicos<br>  
        <input type="checkbox" name="analisis3" value="Paleobotánicos"  <?php for ($i=0;$i<5;$i++) {  if ($cadena_analisis[$i]=="Paleobotánicos"){?> checked  <?php   } }  ?>   >Paleobotánicos<br>
        <input type="checkbox" name="analisis" value="Otros" onclick="document.getElementById('analisisotros').disabled = !this.checked">Otros<br>  
        <br>  
        <input name="analisisotros" id="analisisotros" disabled type="text" maxlength="15" />
        </fieldset>  

        </tr>
          		</div>	


              <div class="col-md-12">
          <br>
          <label>Descripcion:</label>
          <textarea  name="descripcion" id="descripcion" class='form-control' maxlength="255" ><?php echo utf8_encode($datos_investigacion->inv_descripcion);?></textarea>
            </div>

          <div class="col-md-12">
          <br>
          <label>Observaciones:</label>
          <textarea  name="observaciones" id="observaciones" class='form-control' maxlength="255" ><?php echo utf8_encode($datos_investigacion->inv_observaciones);?></textarea>
          </div>






				<div class="col-md-12 pull-right">
				<hr>
					<button type="submit" class="btn btn-success">Actualizar datos</button>
				</div>
				</form>
			</div>
        </div>
    </div>     
</body>
</html> 