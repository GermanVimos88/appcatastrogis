<?php



	class actividadUsuario{

		public function __construct(){

		}


	public function registro_actividad($usuario,$actividad,$documento,$id){

		include ("Log.php");

		switch ($usuario) {
			
		//Agregamos los usuarios habilitados en el sistema

		
		case 'usuario':		$log = new Log("log", "/home/Documentos/logs/usuario/".$usuario);
							$log->insert($usuario.": ".$actividad.' '.$documento.'-'.$id, false, true, true);							
							break;
		
							}



	}

}





?>
